const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('./ucautotech.db', (err) => {
    if (err) {
        console.error('[DB ERROR] Failed to connect to SQLite database:', err.message);
    } else {
        console.log('[DB] Connected to local UCAUTOTECH SQLite database.');
    }
});

// Initialize tables
db.serialize(() => {
    db.run(`CREATE TABLE IF NOT EXISTS customers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        phone TEXT UNIQUE,
        name TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS job_cards (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        job_code TEXT UNIQUE,
        phone TEXT,
        vehicle TEXT,
        issue TEXT,
        status TEXT DEFAULT 'Received',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);
});

module.exports = db;
